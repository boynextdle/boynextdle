# BOYNEXTDOOR Songdle

Daily BOYNEXTDOOR song guessing game (plain HTML/CSS/JS, no build step).

## Run locally
Open `index.html` in a browser.

## Publish with GitHub Pages
Settings > Pages > Source: `main` branch, `/ (root)` > Save.

## Edit
- Songs & albums: `SG` and `AL` in `script.js`
- Number of guesses: `MAX` in `script.js`
- Background: replace `bg.jpg`
